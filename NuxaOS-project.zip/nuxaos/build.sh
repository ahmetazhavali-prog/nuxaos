#!/usr/bin/env bash
# NuxaOS ISO build script. Debian/Ubuntu uzerinde calistirin:  ./build.sh
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ]; then exec sudo "$0" "$@"; fi

echo "==> Bagimliliklar kuruluyor"
apt-get update
apt-get install -y live-build debootstrap debian-archive-keyring xorriso squashfs-tools \
  mtools dosfstools syslinux syslinux-common isolinux grub-pc-bin grub-efi-amd64-bin \
  grub-common cpio rsync

echo "==> Onceki build temizleniyor"
lb clean || true

echo "==> Yapilandirma"
lb config

echo "==> ISO insa ediliyor (internet gerekir, 15-40 dk surebilir)"
lb build 2>&1 | tee build.log

ISO="$(ls -1 *.iso | head -n1)"
mv -f "$ISO" NuxaOS.iso
sha256sum NuxaOS.iso | tee NuxaOS.iso.sha256
echo "==> Hazir: $(pwd)/NuxaOS.iso"
