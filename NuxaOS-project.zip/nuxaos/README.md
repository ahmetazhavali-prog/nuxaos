# NuxaOS 0.1 (MVP)

Linux tabanli (Debian 12 "bookworm" + live-build) hafif masaustu isletim sistemi.
Masaustu: Openbox + tint2 + PCManFM + LXTerminal. Ad, menu ve kimlik: NuxaOS.

## ISO uretmek (Debian/Ubuntu, tek komut)
    ./build.sh
Cikti: NuxaOS.iso (BIOS + UEFI, hybrid). Yaklasik 700-900 MB, internet gerekir.
Not: WSL yerine gercek Debian/Ubuntu makine veya VM kullanin. Diskte ~10 GB bos yer olsun.

## VirtualBox
1. Yeni -> Tur: Linux, Surum: Debian (64-bit). RAM 2048 MB, disk gerekmez (live).
2. Ayarlar > Ekran: Grafik denetleyici **VMSVGA**, Video belegi 64-128 MB.
3. Ayarlar > Depolama: bos optik surucuye NuxaOS.iso'yu sec.
4. UEFI denemek icin Ayarlar > Sistem > "EFI'yi etkinlestir". Baslat.
Otomatik oturum acar (kullanici: nuxa, parola: live).

## USB'ye yazma (gercek donanim)
- Windows: Rufus, "DD Gorsel modu" ile yaz.
- Mac/Linux: balenaEtcher veya
      sudo dd if=NuxaOS.iso of=/dev/sdX bs=4M status=progress conv=fsync
  (/dev/sdX yerine USB aygitini dogru yazin; icindeki her sey silinir.)
Sonra bilgisayari USB'den boot edin (F12/F2/Esc/Del).

## Kisayollar
Super+Space: NuxaOS menusu, Super+E: dosyalar, Super+T: terminal.
